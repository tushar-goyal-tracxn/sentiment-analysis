# import nltk
#
# nltk.download('vader_lexicon')

from nltk.sentiment import SentimentIntensityAnalyzer
# sia = SentimentIntensityAnalyzer()
# print(sia.polarity_scores('I am really happy now'))


def get_sentiment(text:str):
    sia = SentimentIntensityAnalyzer()
    score = sia.polarity_scores(text)
    sentiment = 'Positive' if score.get('compound')>=0.5 else \
        'Negative' if score.get('compound')<=-0.5 else 'Neutral'
    return sentiment


if __name__== '__main__':
    print(get_sentiment('I am really happy now'))
